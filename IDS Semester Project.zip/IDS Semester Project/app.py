# app.py
import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

# Custom CSS for better UX
st.set_page_config(
    page_title="Loan Approval AI",
    page_icon="🤖",
    layout="centered",
    initial_sidebar_state="expanded"
)

def safe_load_model(model_path):
    """Safe model loading with version compatibility fixes"""
    try:
        model = joblib.load(model_path)
        # Remove problematic attributes if they exist
        for attr in ['monotonic_cst', '_monotonic_cst']:
            if hasattr(model, attr):
                delattr(model, attr)
        return model
    except Exception as e:
        st.error(f"Model loading failed: {str(e)}")
        return None

@st.cache_resource
def load_resources():
    try:
        data = pd.read_csv("cleaned_dataset.csv")
        model = safe_load_model("best_model.pkl")
        return data, model
    except Exception as e:
        st.error(f"Loading error: {str(e)}")
        return None, None

data, model = load_resources()

# Sidebar Inputs - Now with ALL required features
with st.sidebar:
    st.title("📝 Loan Application")
    
    with st.expander("Personal Details"):
        age = st.slider("Age", 18, 70, 30)
        family = st.slider("Family Members", 1, 10, 2)
        education = st.selectbox("Education Level", 
                               ["Undergraduate", "Graduate", "Advanced/Professional"])
    
    with st.expander("Financial Details"):
        income = st.number_input("Annual Income ($)", 10000, 500000, 50000, step=1000)
        experience = st.slider("Work Experience (Years)", 0, 30, 5)
        cca = st.slider("Credit Card Avg. Spending ($)", 0, 5000, 1000)
    
    with st.expander("Banking Products"):
        credit_card = st.checkbox("Have Credit Card")
        mortgage = st.checkbox("Have Mortgage")
        online = st.checkbox("Use Online Banking")
        cd_account = st.checkbox("Have CD Account")
        securities_account = st.checkbox("Have Securities Account")
    
    predict_clicked = st.button("Check Approval", type="primary")

# Main Prediction Logic
if predict_clicked and model:
    with st.spinner("Analyzing your application..."):
        try:
            # Prepare input with ALL features the model expects
            input_data = pd.DataFrame({
                "Age": [age],
                "Income": [income],
                "Experience": [experience],
                "Family": [family],
                "CCAvg": [cca],
                "Education": [1 if education == "Graduate" else 2 if education == "Advanced/Professional" else 0],
                "CreditCard": [1 if credit_card else 0],
                "Mortgage": [1 if mortgage else 0],
                "Online": [1 if online else 0],
                "CD.Account": [1 if cd_account else 0],
                "Securities.Account": [1 if securities_account else 0]
            })
            
            # Ensure correct feature order
            if hasattr(model, 'feature_names_in_'):
                input_data = input_data[model.feature_names_in_]
            
            # Make prediction
            prediction = model.predict(input_data)[0]
            proba = model.predict_proba(input_data)[0][1] if hasattr(model, 'predict_proba') else 0.75
            
            # Display results
            col1, col2 = st.columns(2)
            with col1:
                if prediction == 1:
                    st.success("## 🎉 Approved!")
                    st.balloons()
                else:
                    st.error("## ❌ Not Approved")
                st.metric("Confidence", f"{proba:.0%}")
            
            with col2:
                fig, ax = plt.subplots(figsize=(6, 1))
                ax.barh([''], [proba], color='green' if prediction == 1 else 'red')
                ax.set_xlim(0, 1)
                st.pyplot(fig)
            
            # Recommendations
            with st.expander("💡 How to improve approval chances"):
                if income < 50000:
                    st.write("💰 Increase your income")
                if not securities_account:
                    st.write("📈 Open a securities account")
                if cca < 2000:
                    st.write("💳 Increase credit card usage")

        except Exception as e:
            st.error(f"Prediction error: {str(e)}")

# Data Visualization Section
if data is not None:
    st.header("📊 Approval Insights")
    tab1, tab2 = st.tabs(["Approval Rates", "Income Analysis"])
    
    with tab1:
        fig, ax = plt.subplots()
        sns.countplot(data=data, x="Personal.Loan", ax=ax)
        ax.set_xticklabels(["Denied", "Approved"])
        st.pyplot(fig)
    
    with tab2:
        fig, ax = plt.subplots()
        sns.boxplot(data=data, x="Personal.Loan", y="Income", ax=ax)
        st.pyplot(fig)

st.caption("Note: Predictions are based on historical data and may vary.")