import pandas as pd

df = pd.read_csv("cleaned_dataset.csv")
print("📋 Columns in dataset:")
print(df.columns.tolist())
