import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib

# Load dataset
df = pd.read_csv("cleaned_dataset.csv")

# Split features and target
X = df.drop("Personal.Loan", axis=1)
y = df["Personal.Loan"]

# Split into train/test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the correct model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Save the model
joblib.dump(model, "random_forest_model.pkl")
print("✅ Model trained and saved as random_forest_model.pkl")
